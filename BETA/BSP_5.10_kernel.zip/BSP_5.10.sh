#!/bin/bash

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"

echo "Installing Rockchip BSP 5.10 kernel"
echo "Unzipping assets"

unzip -X -o "$SCRIPT_DIR/BSP_5.10.zip" -d /
sleep 1

echo "Install drivers"

# install kernel drivers
H=/home/ark; C=bf621d15f009509557d6b28f81427651695cac20; F=libmali-bifrost-g31-g29p1.so; U="https://raw.githubusercontent.com/JeffyCN/mirrors/$C/lib"; ICD=/usr/share/vulkan/icd.d/mali_icd.json
cd "$H" && \
curl -fL -o "$F.aarch64" "$U/aarch64-linux-gnu/$F" && \
echo "9a931238bf5dd65d58e30bc92d6ab4e8417f858b5778dc2fb7fb6430dc7d3b83  $F.aarch64" | sha256sum -c && \
curl -fL -o "$F.armhf.orig" "$U/arm-linux-gnueabihf/$F" && \
echo "82e89b347b59c75005d3b206367564032eb50c0386f3963dee09ba09a31ae289  $F.armhf.orig" | sha256sum -c && \
cp "$F.armhf.orig" "$F.new" && \
dd if="$F.armhf.orig" bs=1 skip=52 count=32 status=none > phdr.new && \
dd if="$F.armhf.orig" bs=1 skip=116 count=224 status=none >> phdr.new && \
dd if="$F.armhf.orig" bs=1 skip=84 count=32 status=none >> phdr.new && \
dd if=phdr.new of="$F.new" bs=1 seek=52 conv=notrunc status=none && \
echo "92455f88319628cb4623564c6dadcc3024123e8ae245eea7e8e13721efa87595  $F.new" | sha256sum -c && \
sudo install -m 644 -o root -g root "$F.aarch64" "/usr/lib/aarch64-linux-gnu/$F" && \
sudo install -m 644 -o root -g root "$F.new" "/usr/lib/arm-linux-gnueabihf/$F" && \
for D in /usr/lib/aarch64-linux-gnu /usr/lib/arm-linux-gnueabihf; do sudo ln -sfn "$F" "$D/libMali.so" && sudo ln -sfn libMali.so "$D/libmali-bifrost-g31-rxp0-gbm.so" || break; done && \
sudo ldconfig && \
printf 'SUBSYSTEM=="dma_heap", GROUP="video", MODE="0660"\n' | sudo tee /etc/udev/rules.d/99-dma-heap.rules >/dev/null && \
sudo udevadm control --reload-rules && sudo udevadm trigger --subsystem-match=dma_heap && \
printf '{\n    "file_format_version" : "1.0.0",\n    "ICD": {\n        "library_path": "libmali.so",\n        "api_version" : "1.3.276"\n    }\n}\n' | sudo tee "$ICD" >/dev/null && \
{ grep -q '^VK_ICD_FILENAMES=' /etc/environment || echo "VK_ICD_FILENAMES=$ICD" | sudo tee -a /etc/environment >/dev/null; } && \
sudo mkdir -p /etc/systemd/system.conf.d && \
printf '[Manager]\nDefaultEnvironment=VK_ICD_FILENAMES=%s\n' "$ICD" | sudo tee /etc/systemd/system.conf.d/vulkan-mali.conf >/dev/null && \
sha256sum /usr/lib/aarch64-linux-gnu/$F /usr/lib/arm-linux-gnueabihf/$F && \
echo "MALI INSTALL DONE - reboot now"

echo "Update libasound.so.2.0.0"

# update libasound
if dpkg-divert --list /usr/lib/arm-linux-gnueabihf/libasound.so.2.0.0 | grep -q .; then
  sudo dpkg-divert --local --no-rename --remove /usr/lib/arm-linux-gnueabihf/libasound.so.2.0.0
fi
sudo apt-get update
sudo apt-get install --reinstall -y libasound2t64:armhf
sudo ldconfig

echo "Rebooting..."

sleep 3

sudo reboot